function [ curves, ts, areas, fs ] = run_sim( initialcurve, odef, varargin )
    % Run a hele show simulation
    % Parameters:
    %   initialcurve - the initial interface (as a complex valued polygon)
    %   odef - the ode function to use. 
    %          Can be either:
    %              * one_phase_interior_ode
    %              * one_phase_exterior_ode
    % Options:
    %   sources - vector of the sources (and sinks) locations
    %   Q       - the rate of injection/suction. Can be either a numeric
    %             value for each singularity or a function of time (for 
    %             changing rate of injection).
    %   linesources - matrix of size (m x 2) of 'm' line sources
    %   QL      - the rate of injection for the line sources
    %   gamma   - the surface tension
    %   dtfunc  - the function for determining the delta time at each step.
    %             Can be either:
    %               * @dynamicdtfunc - decide on the delta time according
    %               to the velocity and the min edge length.
    %               * constdtfunc(dt) - constant delta time of dt.
    %   maxt    - stop when reaching maxt time
    %   maxiter - stop when reaching maxiter iterations
    %   nsamples - the number of samples per edge
    %   minedge - the minimum length of an edge in the interface
    %   maxpts - the maximum number of vertices in the interface
    %   show    - show the flow during the calculations
    %
    % Outputs:
    %   curves - cell of the interfaces during the iterations
    %   ts     - the time passed (from the beginning) at each iteration
    %   areas  - the areas of the interior fluid during the iterations.
    %   fs     - the complex potential found at each iteration
    
    p = inputParser;
    p.addOptional('sources', []);
    p.addOptional('Q', 1);
    p.addOptional('linesources', []);
    p.addOptional('QL', 1);
    p.addOptional('gamma', 1e-5);
    p.addOptional('dtfunc', @dynamicdtfunc);
    p.addOptional('maxt', 1);
    p.addOptional('maxiter', 100);
    p.addOptional('nsamples', 4);
    p.addOptional('minedge', 2e-2);
    p.addOptional('maxpts', 1000);
    p.addOptional('show', 0);
    parse(p, varargin{:});

    Qfunc = p.Results.Q;
    QLfunc = p.Results.QL;
    
    if isnumeric(Qfunc)
        Qfunc = @(x) Qfunc;
    end
    if isnumeric(QLfunc)
        QLfunc = @(x) QLfunc;
    end
    
    % Test whether a gpu can be used
    if gpuDeviceCount > 0
        usegpu = 1;
    else
        usegpu = 0;
    end
    
    odefunc = @(t, curve) odef(t, curve, p.Results.sources, Qfunc, ...
        p.Results.linesources, QLfunc, p.Results.gamma, p.Results.nsamples, usegpu);
    
    [curves, ts, areas, fs] = explicitEuler(initialcurve, odefunc, ...
        p.Results.dtfunc, p.Results.maxt, p.Results.maxiter, ...
        p.Results.minedge, p.Results.maxpts, p.Results.show);
    
end

