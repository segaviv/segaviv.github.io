function [ normals ] = znormals( curve, method )

    if nargin < 2
        method = 'wpoly';
    end

    if strcmp(method, 'wpoly')
        cp1 = curve([2:end 1]) - curve;
        cm1 = curve - curve([end 1:end-1]);
        normals = -1i*(cp1./abs(cp1) + cm1./abs(cm1));
        normals = normals ./ abs(normals);
        if turning_number(curve) > 0
            normals = -normals;
        end
        
    elseif strcmp(method, 'curvediff')
        normals = 1i*(circshift(curve, 1) - circshift(curve, -1));
        normals = normals ./ abs(normals);
        if turning_number(curve) > 0
            normals = -normals;
        end
    elseif strcmp(method, 'spline')
        cs = zcscvn(curve);
        dcs = fnder(cs);
        a = fnval(dcs, dcs.breaks(1:end-1));
        normals = -1i * complex(a(1,:), a(2,:)).';
        normals = normals ./ abs(normals);
    end

end

