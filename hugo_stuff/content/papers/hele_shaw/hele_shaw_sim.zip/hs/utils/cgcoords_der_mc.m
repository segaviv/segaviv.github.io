function [ D ] = cgcoords_der_mc( curve, holes, pts, type )

    if nargin < 4
        type = 0;
    end

    n = length(curve);
    m = length(pts);
    
    nh = zeros(length(holes), 1);
    for i = 1 : size(holes, 2)
        nh(i) = length(holes{i});
    end
    cnh = [0;cumsum(nh)];

    D = zeros(m, n + cnh(end));
    if gpuDeviceCount
        if type == 0
            D(:, 1:n) = gather(cgcoords_derivative_gpu(curve, pts));
        else
            D(:, 1:n) = gather(cginvcoords_derivative_gpu(curve, pts));
        end
    else
        if type == 0
            [~, D(:, 1:n)] = cgcoords(curve, pts);
        else
            [~, D(:, 1:n)] = cginvcoords(curve, pts);
        end
    end
    
    for i = 1 : length(holes)
        if gpuDeviceCount
            D(:, n + cnh(i) + 1 : n + cnh(i+1)) = -gather(cgcoords_derivative_gpu(holes{i}, pts));
        else
            [~, D(:, n + cnh(i) + 1 : n + cnh(i+1))] = cgcoords(holes{i}, pts);
            D(:, n + cnh(i) + 1 : n + cnh(i+1)) = -D(:, n + cnh(i) + 1 : n + cnh(i+1));
        end
    end

end

