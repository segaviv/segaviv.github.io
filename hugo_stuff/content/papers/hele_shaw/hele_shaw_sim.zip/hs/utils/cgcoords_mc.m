function [ C ] = cgcoords_mc( curve, holes, pts, type )

    if nargin < 4
        type = 0;
    end

    n = length(curve);
    m = length(pts);
    
    nh = zeros(length(holes), 1);
    for i = 1 : size(holes, 2)
        nh(i) = length(holes{i});
    end
    cnh = [0;cumsum(nh)];

    C = zeros(m, n + cnh(end));
    if gpuDeviceCount
        if type == 0
            C(:, 1:n) = gather(cgcoords_gpu(curve, pts));
        else
            C(:, 1:n) = gather(cginvcoords_gpu(curve, pts));
        end
    else
        if type == 0
            C(:, 1:n) = cgcoords(curve, pts);
        else
            C(:, 1:n) = cginvcoords(curve, pts);
        end
    end
    
    for i = 1 : length(holes)
        if gpuDeviceCount
            C(:, n + cnh(i) + 1 : n + cnh(i+1)) = gather(-cgcoords_gpu(holes{i}, pts));
        else
            C(:, n + cnh(i) + 1 : n + cnh(i+1)) = -cgcoords(holes{i}, pts);
        end
    end

end

