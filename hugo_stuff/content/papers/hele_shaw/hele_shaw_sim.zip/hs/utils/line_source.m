function [ c, d ] = line_source( pts, lines )
   
    if isempty(lines)
        c = zeros(length(pts), 0);
		d = zeros(length(pts), 0);
        return;
    end
	
    p1 = reshape(lines(:, 1), 1, size(lines, 1));
    p2 = reshape(lines(:, 2), 1, size(lines, 1));
    
    ang = wrapTo2Pi(angle(p2 - p1));
%     mid = 0.5*(p1 + p2);
%     pts = (pts - mid) * exp(1i * -ang);
%     p2 = (p2 - mid) * exp(1i * -ang);
%     p1 = (p1 - mid) * exp(1i * -ang);
%     c = (p2 - pts) .* (log(p2 - pts) - 1) - ...
%         (p1 - pts) .* (log(p1 - pts) - 1);
    fpts = repmat(pts, 1, length(p1));
    p2mpts = -bsxfun(@minus, fpts, p2);
    p1mpts = -bsxfun(@minus, fpts, p1);
    
    ep2 = bsxfun(@times, p2mpts, exp(1i * -ang));
    ep1 = bsxfun(@times, p1mpts, exp(1i * -ang));
%     logp2 = logbranch(ep2, 0);
%     logp1 = logbranch(ep1, 0);
    logp2 = log(ep2);
    logp1 = log(ep1);
    
    c = ep2 .* (logp2 - 1) - ep1 .* (logp1 - 1);
    
    d = bsxfun(@times, logp1 - logp2, exp(1i * -ang));
%     d = logp1 - logp2;
    
%     c  = exp(1i * -ang) .* ( ...
%             (p2 - pts) .* (log((p2 - pts) .* exp(1i*-ang)) - 1) - ...
%             (p1 - pts) .* (log((p1 - pts) .* exp(1i*-ang)) - 1));
    
%     d = log(p1 - pts) - log(p2 - pts);
%     d = exp(1i * -ang) .* ( ...
%         log((p1 - pts) .* exp(1i*-ang)) - ...
%         log((p2 - pts) .* exp(1i*-ang)));
    
    
%     dc = conj(p2 - p1) * (pts - p1);
%     
%     r = (imag(dc / abs(p2 - p1)));
%     a = -real(dc);
%     b = a + abs(p2 - p1);
%     
%     
%     c = 0.5 * (b .* (log(r.^2+b.^2) - 2) - a .* (log(r.^2+a.^2) - 2)) + ...
%         r .* (atan2(r, b) - atan2(r, a));
%     
%     d = 0.5*(log(r.^2+b.^2) + log(r.^2+a.^2)) - 1i * (atan(b./r) - atan(a./r));
    
end

