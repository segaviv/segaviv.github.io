function [h] = colorcurve( curve, col )

    if length(col) == 1
        col = repmat(col, length(curve), 1);
    end

    col = reshape(col, length(col), 1);
    curve = reshape(curve, length(curve), 1);
    
    curve = curve([1:end 1]);
    col = col([1:end 1]);
    
    h = surface([real(curve),real(curve)], [imag(curve),imag(curve)], [zeros(size(curve)), zeros(size(curve))], ...
        [col,col], 'facecol', 'no', 'edgecol', 'interp', 'linew', 2);
    colormap(jet);
    axis equal;

end

