function [ cs ] = zcscvn( curve, alpha )
    if nargin < 2
        alpha = (1/2);
    end
%     if knots == 0
%         cs = cscvn([real([curve; curve(1)]), imag([curve; curve(1)])].');
%     else
    cs = csape(cumsum([0, abs(curve([2:end 1])-curve).'.^alpha]), ...
        [real([curve; curve(1)]).'; imag([curve; curve(1)]).'], ...
        'periodic');
%     end


end

