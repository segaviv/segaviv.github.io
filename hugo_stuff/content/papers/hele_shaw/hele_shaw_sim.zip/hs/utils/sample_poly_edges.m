function [ pts, H ] = sample_poly_edges( curve, nsamples, include_verts )
    if nargin < 3
        include_verts = 1;
    end
    if include_verts
        fracs = (0:nsamples-1).' ./ nsamples;
    else
        fracs = (1:nsamples).' ./ (nsamples+1);
    end
    if nargout > 1
        H = kron(speye(length(curve)), 1-fracs) + kron(circshift(speye(length(curve)), -1), fracs);
        pts = H * curve;
    else
        pts = kron(curve, 1-fracs) + kron(curve([2:end 1]), fracs);
    end

end

