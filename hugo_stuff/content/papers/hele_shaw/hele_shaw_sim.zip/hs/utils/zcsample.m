function [ z ] = zcsample( cs, n, normalized )
    if isnumeric(cs)
        cs = zcscvn(cs, 1);
    end
    if nargin < 2
        n = length(cs.breaks) - 1;
    end
    if nargin < 3
        normalized = 1;
    end
    if length(n) == 1
        n = ((0 : (n-1)).' ./ n);
    end
    if normalized
        n = n * cs.breaks(end);
    end

    xy = fnval(cs, n);

    z = complex(xy(1,:).', xy(2,:).');
end

