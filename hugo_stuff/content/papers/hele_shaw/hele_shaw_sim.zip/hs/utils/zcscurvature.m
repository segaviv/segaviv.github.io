function [ k ] = zcscurvature( cs, n, normalized )
    if nargin < 2
        n = length(cs.breaks) - 1;
    end
    if nargin < 3
        normalized = 1;
    end
    

    ct = fnder(cs);
    ctt = fnder(ct);

    Ct = zcsample(ct, n, normalized);
    Ctt = zcsample(ctt, n, normalized);

    k = imag(conj(Ct) .* Ctt) ./ (abs(Ct).^3);

end

