function [ num ] = turning_number( curve )
    e1 = (curve - circshift(curve, 1));
    e2 = (circshift(curve, -1) - curve);
    num = sum(asin(imag(e1 .* conj(e2) ./ (abs(e1) .* abs(e2)))));
    
end

