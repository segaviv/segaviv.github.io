function [ curve, newstatic ] = sample_spline( cs, n, minedgelength, sigma, staticverts )

    if isnumeric(cs)
        cs = zcscvn(cs, 1);
    end

    if nargin < 2
        n = length(cs.breaks) - 1;
    end
    if nargin < 3
        minedgelength = 0;
    end
    if nargin < 4
        sigma = 1.5;
    end
    if nargin < 5
        staticverts = [];
    end

%     origk = sqrt(abs(zcscurvature(cs, cs.breaks(1:end-1), 0)));
%     origk = (abs(zcscurvature(cs, cs.breaks(1:end-1), 0))).^(1/4);
    origk = log(4 + abs(zcscurvature(cs, cs.breaks(1:end-1), 0)));
%     origk = abs(zcscurvature(cs, cs.breaks(1:end-1), 0));
%     origk = abs(zcurvature(zcsample(cs, cs.breaks(1:end-1), 0)));

    % Smooth curvature?
    k = imgaussfilt(origk, sigma);
%     for i = 1 : size(staticverts, 1)
%         k(staticverts(i, 1):staticverts(i, 2)) = 0;
%     end
    ds = diff(cs.breaks.');
    kp1 = k([2:end 1]);
    
%     zrs = find(sign(k) ~= sign(kp1));
%     zrst = -k(zrs) .* ds(zrs) ./ (kp1(zrs) - k(zrs));
    
    
    
    % Assuming the curvature is linear between each two knots
    areas = 0.5*(kp1 + k) .* ds;
    
    % The cumsum of the areas
    ca = [0; cumsum(areas)];
    
    % The area breaks (break total area to equal parts with area='c')
    c = ca(end) ./ n;
%         areabreaks = ((1:(n-1)).' ./ n) * ca(end);
    if nargin >= 3
        c2 = minedgelength * max(k);
        c = max(c2, c);
%         areabreaks = (c:c:ca(end)).';
    end
    
    areabreaks = (c:c:(ca(end)-c)).';
%     if ca(end) - areabreaks(end) > c*1.5
%         areabreaks(end + 1) = 0.5*(ca(end) + areabreaks(end));
%     end
    
    % Find between which knots each area break falls
    [~, bins] = histc(areabreaks, ca);
    
    % Find where between the knots...
    A = (kp1(bins) - k(bins)) ./ (2*ds(bins));
    B = k(bins);
    C = -(areabreaks - ca(bins));
    
    t = (-B + sqrt(B.^2 - 4*A.*C)) ./ (2*A);
    t(abs(A)<1e-6) = -C(abs(A)<1e-6) ./ B(abs(A)<1e-6);
    
    breaks = [0; cs.breaks(bins).' + t];
    
    % Keep all the vertices specified by "keep"
    newstatic = staticverts;
    for i = 1 : size(staticverts, 1)
%         newstatic(i, 1) = sum(breaks<cs.breaks(staticverts(i,1)));
%         newstatic(i, 2) = length(breaks) - sum(breaks>cs.breaks(staticverts(i, 2)));
        
%         newstatic(i, 2) = newstatic(i, 1) + staticverts(i, 2) - staticverts(i, 1);
        

%         breaks = [breaks(breaks<cs.breaks(staticverts(i,1)));
%                     cs.breaks(staticverts(i, 1));
%             breaks(breaks > cs.breaks(staticverts(i,1)) & breaks<cs.breaks(staticverts(i,2)));
%                 cs.breaks(staticverts(i, 2));
%             breaks(breaks>cs.breaks(staticverts(i,2)));  ];
%         newstatic(i, 1) = sum(breaks<cs.breaks(staticverts(i,1))) + 1;
%         newstatic(i, 2) = length(breaks) - sum(breaks>cs.breaks(staticverts(i, 2)));
        
        % Keep the whole hole
        newstatic(i, 1) = sum(breaks<cs.breaks(staticverts(i,1)) - minedgelength) + 1;
        newstatic(i, 2) = newstatic(i, 1) + staticverts(i, 2) - staticverts(i, 1);
        breaks = [breaks(breaks<cs.breaks(staticverts(i,1)));
                  cs.breaks(staticverts(i,1):staticverts(i,2)).';
                  breaks(breaks>cs.breaks(staticverts(i,2)));  ];
    end
    
    % and sample...
    curve = zcsample(cs, breaks, 0);
    
end

