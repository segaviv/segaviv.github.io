function [ kappa, cs, pts ] = zcurvature( curve, method, offset )

    if nargin < 2
        method = 'angle';
    end
    if nargin < 3
        offset = 0;
    end
    
    if strcmp(method, 'angle')
        e1 = circshift(curve, 1) - curve;
        e2 = curve - circshift(curve, -1);
    
        dc = (e1 .* conj(e2)) ./ (abs(e1) .* abs(e2));
        kappa = acos(real(dc)) .* ...
            -sign(imag(dc));
    elseif strcmp(method, 'angle2')
        e1 = circshift(curve, 1) - curve;
        e2 = curve - circshift(curve, -1);
    
        dc = (e1 .* conj(e2)) ./ (abs(e1) .* abs(e2));
        kappa = 2*(real(acos(real(dc))) .* -sign(imag(dc))) ./ (abs(e1) + abs(e2));
    elseif strcmp(method, 'angle3')
        e1 = circshift(curve, 1) - curve;
        e2 = curve - circshift(curve, -1);
    
        dc = (e1 .* conj(e2)) ./ (abs(e1) .* abs(e2));
        dea = (abs(e1).^2 + abs(e2).^2) ./ (abs(e1) + abs(e2));
        kappa = (real(acos(real(dc))) .* -sign(imag(dc))) ./ dea;
    elseif strcmp(method, 'mspline')
        
        cs = zcscvn(curve);
        ct = fnder(cs);
        ctt = fnder(ct);
        breaks = kron(cs.breaks(1:end-1), 1 - offset(:)) + ...
                 kron(cs.breaks(2:end), offset(:));
        Ct = fnval(ct, breaks);
        Ctt = fnval(ctt, breaks);
        kappa = (Ct(1,:) .* Ctt(2,:) - Ct(2,:) .* Ctt(1,:)) ./ ...
        ((Ct(1,:).^2 + Ct(2,:).^2) .^ (3/2));
        kappa = kappa.';
        
    elseif strcmp(method, 'spline')
        n = length(curve);
        c = make_constraints(n, 3) * curve;
        c = c.';
        
        Ct = [real(c(n+1:2*n)); imag(c(n+1:2*n))];
        Ctt = 2*[real(c(2*n+1:3*n)); imag(c(2*n+1:3*n))];
        kappa = (Ct(1,:) .* Ctt(2,:) - Ct(2,:) .* Ctt(1,:)) ./ ...
        ((Ct(1,:).^2 + Ct(2,:).^2) .^ (3/2));
        kappa = kappa.';
    elseif strcmp(method, 'danielle')
        boundary = [real(curve), imag(curve)];
        Cp = circ_central_diff_cols(boundary);
        ds = sqrt(Cp(:,1).^2 + Cp(:,2).^2);

        Cs = [Cp(:,1)./ds Cp(:,2)./ds];
        Css = [circ_central_diff_cols(Cs(:,1))./ds  circ_central_diff_cols(Cs(:,2))./ds];
        kappa = sqrt(Css(:,1).^2 + Css(:,2).^2); % I think this is abs(kappa)...
        N = [Css(:,1) ./ (kappa + sqrt(eps)) Css(:,2) ./ (kappa + sqrt(eps))];
    end


end

function res = circ_central_diff_cols(a)
    diff1 = [a(3:end,:) ; a(1:2,:)] - a;
    diff2 = a - [a(end-1:end,:) ; a(1:end-2,:)];
    res = (diff1 + diff2) / 2;
end
