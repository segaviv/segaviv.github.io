function [ res ] = dynamicdtfunc( curve, dfdt, t )

    res = min(0.5*(abs(curve([2:end 1])-curve)+abs(curve([end 1:end-1])-curve)) ./ abs(dfdt)) * 0.5;

end

