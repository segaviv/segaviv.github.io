function [ dfdt, f, v ] = one_phase_exterior_ode( t, curve, sources, Qfunc, linesources, QLfunc, gamma, nsamples, usegpu )

    if nargin < 8
        nsamples = 4;
    end
    if nargin < 9
        usegpu = 1;
    end
    
    m = length(curve) * nsamples;
    n = length(curve);
    ns = length(sources);
    nl = length(linesources);
    
    % Sample the polygon edges (the collocation points)
    [pts, H] = sample_poly_edges(curve, nsamples);
    
    % Calculate the curvature on the vertices
    vkappa = zcurvature(curve, 'angle2');    
    % and interpolate on the edges
    kappa = H * vkappa;
    
    enorms = -1i*(curve([2:end 1]) - curve);
    enorms = enorms ./ abs(enorms);
    enorms = kron(enorms, ones(nsamples, 1));
    % Calculate the coordinates of the collocation points
    if usegpu
        Ainf = cgcoords_gpu(curve, complex(0.0,0));
        C = cgcoords_gpu(curve, pts + 1e-3 * enorms);
        C = bsxfun(@minus, Ainf, C);
    else
        Ainf = cgcoords(curve, complex(0.0,0));
        C = cgcoords(curve, pts + 1e-3 * enorms);
        C = bsxfun(@minus, Ainf, C);
    end
    
    % The strength of the singularities
    Q = zeros(length(sources), 1);
    Q(:) = Qfunc(t);
    QL = zeros(length(linesources), 1);
    QL(:) = QLfunc(t);
    
    % The potential from the point singularities
    plog = (1/(2*pi)) .* ...
        log(repmat(pts, 1, ns) - repmat(sources(:).', m, 1)) * Q;
    
    % The potential from the line singularities
    plines = (1/(2*pi)) .* ...
        line_source(pts, linesources) * QL;
    
    % Solve the least squares problem Ax = b
    A = gather([real(C(:, 1:end-1)), -imag(C(:, 1:end-2))]);
    b = -(real(plog) + real(plines)) - gamma * kappa;
    
    f = A \ b;
    f = gather(complex([f(1:length(curve)-1); 0], [f(length(curve):end); 0;0]));
    
    % Calculate the derivative of the coordinates at the vertices
    normals = znormals(curve);
    if usegpu
        D = -cgcoords_derivative_gpu(curve, curve + 1e-3 * normals);
    else
        [~, D] = cgcoords(curve, curve + 1e-3 * normals);
        D = -D;
    end
    
    % Derivative of point singularities
    dlog = (1/(2*pi)) .* ...
        1./(repmat(curve, 1, ns) - repmat(sources(:).', n, 1)) * Q;
    
    % Derivative of lines singularities
    [~, dlines] = line_source(curve, linesources);
    dlines = (1/(2*pi)) .* dlines * QL;
    % Calculate the speed
    v = dlog + dlines + gather(D * f);
    
    % Calculate the change in the normal direction
    dfdt = real(-v .* normals) .* normals;
end

