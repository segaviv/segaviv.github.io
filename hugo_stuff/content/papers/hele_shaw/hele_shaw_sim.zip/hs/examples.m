
addpath('utils');
%% Exterior flow
a = 2 * pi * (0:99).' ./ 100;
circ = exp(1i * a);

d = circ .* (1 + 0.05*sin(10*a));

[curves, dts] = run_sim(d, @one_phase_exterior_ode, ...
    'dtfunc', constdtfunc(1e-1), ...
    'sources', 0, 'Q', -1, ...
    'maxt', 10, 'maxiter', 20, 'show', 1);

%% Interior flow

a = 2 * pi * (0:99).' ./ 100;
circ = exp(1i * a);

d = circ .* (1 + 0.05*sin(20*a));

[curves, dts] = run_sim(d, @one_phase_interior_ode, ...
    'dtfunc', constdtfunc(0.7e-1), ...
    'sources', 0, 'Q', 1, ...
    'maxt', 10, 'maxiter', 20, 'show', 1);
