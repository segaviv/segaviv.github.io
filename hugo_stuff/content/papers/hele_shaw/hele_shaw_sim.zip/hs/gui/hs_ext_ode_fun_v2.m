function [ dfdt, err ] = hs_ext_ode_fun_v2( curve, sources, Q, gamma, linesources)

    if nargin < 4
        linsources = [];
    end
    
    % Normalize gamma according to mean edge length
    gamma = gamma .* mean(abs(curve - circshift(curve, -1)));
    
    n = length(curve);
    ns = length(sources);
    nsamples = 4;
    
    
    % Find the potential
    curvature = zcurvature(curve, 'angle2');
%     fracs = (0 : nsamples - 1).' ./ (nsamples);
    fracs = (1 : nsamples).' ./ (nsamples+1);
    H = kron(speye(length(curve)), 1-fracs) + ...
        kron(circshift(speye(length(curve)), -1), fracs);
    pts = H * curve;
    m = length(pts);

    enorms = -1i * (curve([2:end 1]) - curve);
    enorms = enorms ./ abs(enorms);
    enorms = kron(enorms, ones(nsamples, 1));

    if gpuDeviceCount > 0
%         C = cginvcoords_gpu(curve, pts);
        Ainf = cgcoords_gpu(curve, complex(0.0, 0));
        C = cgcoords_gpu(curve, pts + 1e-4 * enorms);
        C = bsxfun(@minus, Ainf, C);
        % f(z) = (Ainf - C) * f
    else
        Ainf = cgcoords(curve, complex(0.0, 0));
        C = cgcoords(curve, pts + 1e-4 * enorms);
        C = bsxfun(@minus, Ainf, C);
    end
    
    p = -log(repmat(pts, 1, ns) - repmat(sources(:).', m, 1)) * Q;
    
    kappa = H * curvature;
    
    if ~isempty(linesources)
        slines = line_source(pts, linesources(:, 1), linesources(:, 2));
    else
        slines = 0;
    end
    
    b = -real(p - sum(slines, 2)) + gamma * kappa;
    
    A = [real(C), -imag(C(:, 1:end-1))];

%     f = A \ b;

    f = A' * A \ (A' * b);

    f = [f;0];
    f = complex(f(1:length(curve)), f(length(curve)+1:end));
    f = gather(f);
    
%     err = norm(real(C*f)-b);
    err = 0;

    % The normals of the curve
    nrms = znormals(curve);
%     nrms2 = znormals(curve2);
    
    n = length(curve);
    
    
    % Calculate the speed...
%     [~, D] = cgcoords(curve2, flipud(curve2 - 1e-3*nrms2));
%     [~, D] = cginvcoords(curve, curve + 1e-3 * znormals(curve));
    if gpuDeviceCount
%         D = cginvcoords_derivative_gpu(curve, curve + 1e-3*znormals(curve));
        D = -cgcoords_derivative_gpu(curve, curve + 1e-3*znormals(curve));
%         [~, D] = cgcoords(curve, curve + 1e-3 * znormals(curve));
%         D = -D;
    else
        [~, D] = cgcoords(curve, curve + 1e-3 * znormals(curve));
        D = -D;
    end
    
    if ~isempty(linesources)
        [~, dlines] = line_source(curve, linesources(:, 1), linesources(:, 2));
    else
        dlines = 0;
    end
%     [~, D] = cgsplinecoords(curve, curve, 3);

    

    dlog = -1./(repmat(curve, 1, ns) - repmat(sources(:).', n, 1)) * Q;
%     dlog = 1./(curve);


    v = sum(dlog, 2) - sum(dlines, 2) + ...
            (D * f);
        
    vn = real(gather(v) .* nrms);
    
    dfdt = vn .* nrms;
end

