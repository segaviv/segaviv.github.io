function [ dfdt ] = hs_ode_fun( curve, sources, Q, gamma, linesources)

    if nargin < 5
        linsources = [];
    end
    
    % Normalize gamma according to mean edge length
    gamma = gamma .* mean(abs(curve - circshift(curve, -1)));
    
    % Find the potential
    p = findpotential(curve, sources, ...
        'method', 'sample', ...     % Sample nsamples points on each edge
        'nsamples', 4, ...          % Number of samples per edge
        'cmethod', 'angle2', ...   % Calculate curvature using a spline
        'gamma', gamma, ...         % The surface tension
        'degree', 1, ...            % The degree of the coordinates
        'incverts', 0, ... % Include the vertices when calculating the potential
        'linesources', linesources, ...
        'Q', Q ...
        );

    % The normals of the curve
    nrms = znormals(curve);
    
    n = length(curve);
    ns = length(sources);
    
    % Calculate the speed...
%     [~, D] = cgsplinecoords(curve, curve - 1e-3 * nrms, 1);
%     [~, D] = cgcoords(curve, curve - 1e-3*nrms);
    if gpuDeviceCount > 0
        D = gather(cgcoords_derivative_gpu(curve, curve - 1e-3*nrms));
    else
        [~, D] = cgcoords(curve, curve - 1e-3*nrms);
    end
    if ~isempty(linesources)
        [~, dlines] = line_source(curve, linesources(:, 1), linesources(:, 2));
    else
        dlines = 0;
    end
%     [~, D] = cgsplinecoords(curve, curve, 3);

    if ~isempty(sources)
        dlog = 1./(repmat(curve, 1, ns) - repmat(sources(:).', n, 1)) * Q;
    else
        dlog = 0;
    end

    v = sum(dlines, 2) + ...
        sum(dlog, 2) + ...
            D * p;
        
    vn = -real(v .* nrms);
    
    dfdt = vn .* nrms;
%     dfdt = -conj(v);
end

