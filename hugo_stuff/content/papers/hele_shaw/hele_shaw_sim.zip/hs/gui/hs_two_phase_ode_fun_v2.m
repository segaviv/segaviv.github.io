function [ dfdt, err ] = hs_two_phase_ode_fun_v2( curve, sources, Q, gamma, linesources, mu1, mu2)

    if nargin < 4
        linsources = [];
    end
    
    % Normalize gamma according to mean edge length
    n = length(curve);
    ns =length(sources);
    
    
    
    % Find the potential
    %{
    p = findpotential(curve2, [ 0; 1./sources], ...
        'method', 'sample', ...     % Sample nsamples points on each edge
        'nsamples', 4, ...          % Number of samples per edge
        'cmethod', 'angle2', ...   % Calculate curvature using a spline
        'gamma', gamma, ...         % The surface tension
        'degree', 1, ...            % The degree of the coordinates
        'incverts', 1, ... % Include the vertices when calculating the potential
        'linesources', linesources, ...
        'invcurve', true ...
        );
    %}
    % Find the potential
    gamma = gamma .* mean(abs(curve - curve([2:end 1])));
    curvature = zcurvature(curve, 'angle2');
    
    % Sample the polygon
    nsamples = 4;
    fracs = (1  : nsamples).' ./ (nsamples + 1);
    H = kron(eye(length(curve)), 1-fracs) + ...
            kron(circshift(eye(length(curve)), -1), fracs);
    pts = H * curve;
%     pts2 = 1./pts;

    % The normals of the curve at the vertices and at the edges
    nrms = znormals(curve);
    enrms = -1i * (circshift(curve, -1) - curve);
    enrms = enrms ./ abs(enrms);
    enrms = kron(enrms, ones(nsamples, 1));

    % Calculate the coordinates for the samples

    if gpuDeviceCount > 0
        C = gather(cgcoords_gpu(curve, pts-1e-3*enrms));
        D = gather(cgcoords_derivative_gpu(curve, pts-1e-3*enrms));
        
        Ainf = cgcoords_gpu(curve, complex(0.0, 0));
        C2 = cgcoords_gpu(curve, pts+1e-3*enrms);
        C2 = bsxfun(@minus, Ainf, C2);
        
        D2 = -gather(cgcoords_derivative_gpu(curve, pts+1e-3*enrms));
    else
        [C, D] = cgcoords(curve, pts-1e-3*enrms);        
        
        Ainf = cgcoords(curve, complex(0.0, 0));
        [C2, D2] = cgcoords(curve, pts+1e-3*enrms);
        C2 = bsxfun(@minus, Ainf, C2);
        D2 = -D2;
        
        %     [C, D] = cgsplinecoords(curve, pts, 3);
    end

    
    % Make the constraint matrix
    % (1) Re( mu1 * Phi1 - mu2 * phi2) = gamma * kappa
    % (2) n * grad(Phi1) = n * grad(Phi2)
    nD = bsxfun(@times, D, enrms);  
    nD2 = bsxfun(@times, D2, enrms );
    
    mat = [mu1*C, -mu2 * C2;  % (1) ( = gamma * kappa - singularities)
           nD, -nD2        ]; % (2) ( = 0)
    
    % Singularities
    p = mu1 * log(repmat(pts, 1, ns) - repmat(sources(:).', length(pts), 1)) * Q(:) - ...
        mu2 * log(repmat(pts, 1, ns) - repmat(sources(:).', length(pts), 1)) * Q(:);
%         mu2 * log(pts) * Q(:);
        
        
        
    
    % interpolated curvature
    kappa = H * curvature;
    
    b = [-real(p) + gamma * kappa;  % (1)
%     b = [gamma * kappa;  % (1)
         zeros(length(pts), 1)]; % (2)
%          -real(enrms .* (1./(repmat(pts, 1, ns) - repmat(sources(:).', length(pts), 1)) * Q(:) - (1./pts) * Q(:)))];
%          -real(enrms .*  (1./mu1 + 1./mu2)*1./(repmat(pts, 1, ns) - repmat(sources(:).', length(pts), 1)) * Q(:))  ]; % (2)

    % Solve:
    % Re(mat * x) = b
    m = [real(mat(:, 1:end-1)), -imag(mat(:, 2:end-1))];
    
%     x = m \ b;

    x = m' * m \ (m' * b);

    
    Phi1 = complex(x(1:n), [0; x(2*n:3*n-2)]);
%     Calculation of Phi2, for debugging...
    Phi2 = [complex(x(n+1:2*n-1), x(3*n-1 : end)); 0];    

%     m = [real(mat), -imag(mat)];
%     x = m \ b;
%     Phi1 = complex(x(1:n), x(2*n+1:3*n));
%     Phi2 = complex(x(n+1:2*n), x(3*n+1:4*n));

    
    
    % Calculate the speed...
    if gpuDeviceCount > 0
        D = cgcoords_derivative_gpu(curve, curve - 1e-3 * nrms);
    else
        [~, D] = cgcoords(curve, curve - 1e-3 * nrms);
    end

%     [~, D2] = cgcoords(curve2, curve2 - 1e-3 * znormals(curve2));
%     [~, D] = cgsplinecoords(curve, curve - 1e-3 * nrms, 3);
    if ~isempty(linesources)
        [~, dlines] = line_source(curve, linesources(:, 1), linesources(:, 2));
    else
        dlines = 0;
    end
%     [~, D] = cgsplinecoords(curve, curve, 3);


    
    if ~isempty(sources)
        dlog = 1./(repmat(curve, 1, ns) - repmat(sources(:).', n, 1)) * Q(:);
    else
        dlog = 0;
    end


    v = sum(dlog, 2) + ...
        sum(dlines, 2) + ...
        D * Phi1;
%         (D2 * Phi2) .* (-curve2.^2);
        
        
    vn = -gather(real(v .* nrms));
    
    dfdt = vn .* nrms;
    
    err = norm(m*x-b);
end

