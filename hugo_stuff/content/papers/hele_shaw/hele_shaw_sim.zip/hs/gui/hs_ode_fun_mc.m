function [ dfdt, vt, v ] = hs_ode_fun_mc( curve, sources, Q, gamma, linesources, holes, staticverts)

    if nargin < 5
        linesources = [];
    end
    if nargin < 6
        holes = {};
    end
    if nargin < 7
        staticverts = [];
    end
    
    n = length(curve);
    ns = length(sources);
    
    nh = zeros(length(holes), 1);
    for i = 1 : size(holes, 2)
        nh(i) = length(holes{i});
    end
    cnh = [0;cumsum(nh)];
    
    % Normalize gamma according to mean edge length
    gamma = gamma .* mean(abs(curve - circshift(curve, -1)));
    
    curvature = zcurvature(curve, 'angle2');
    
    nsamples = 4;
    
    % Sample points on the boundary and find the potential
    fracs = (1 : nsamples).' ./ (nsamples + 1);
    H = kron(speye(length(curve)), 1-fracs) + ...
        kron(circshift(speye(length(curve)), -1), fracs);
%         pts = kron(curve, 1-fracs) + kron(circshift(curve, -1), fracs);
    
    % Samples for dirrichlet boundary conditions (moving boundary)
    ptsD = H * curve;
    
    % Samples for Neumann boundary conditions (obstacles)
    ptsN = zeros(cnh(end)*4, 1, 'like', 1i);
    nrms = zeros(cnh(end)*4, 1, 'like', 1i);
    for i = 1 : length(nh)
        cur = cnh(i)*4+1:cnh(i+1)*4;
        nrms(cur) = kron(-1i*(holes{i}([2:end 1]) - holes{i}), ones(nsamples, 1));
        nrms(cur) = nrms(cur) ./ abs(nrms(cur));
        
        ptsN(cur) = sample_poly_edges(holes{i}, nsamples) - 1e-3 * nrms(cur);
    end
    
    % Static verts also requires Neumann boundary conditions
    ptsStatic = zeros(0, 1);
    ptsSIndices = zeros(0, 1);
    ptsStaticNormals = zeros(0, 1);
    enormals = -1i*(curve([2:end 1]) - curve);
    enormals = enormals ./ abs(enormals);
    for i = 1 : size(staticverts, 1)
        curpts = ptsD((staticverts(i,1)-1)*4+1:(staticverts(i, 2)-1)*4);
        curnormals = kron(enormals(staticverts(i,1):staticverts(i,2)-1), ones(nsamples, 1));
        ptsStaticNormals = [ptsStaticNormals; curnormals];
        ptsStatic = [ptsStatic; curpts - 1e-3 * curnormals];
        ptsSIndices = [ptsSIndices; ((staticverts(i,1)-1)*4+1:(staticverts(i, 2)-1)*4).'];
    end
    
    m = length(ptsD);

    % Build the coordinates for the multiply connected domain
    C = zeros(m, n + cnh(end));
    D = zeros(length(ptsN), n + cnh(end));
    Ds = zeros(length(ptsStatic), n + cnh(end));
    if gpuDeviceCount
        C = cgcoords_mc(curve, holes, ptsD);
        D = cgcoords_der_mc(curve, holes, ptsN);
        Ds = cgcoords_der_mc(curve, holes, ptsStatic);
%         C(:, 1:n) = cgcoords_gpu(curve, ptsD);
%         D(:, 1:n) = gather(cgcoords_derivative_gpu(curve, ptsN));
%         Ds(:, 1:n) = gather(cgcoords_derivative_gpu(curve, ptsStatic));
%         for i = 1 : length(holes)
%             C(:, n + cnh(i) + 1 : n + cnh(i+1)) = gather(-cgcoords_gpu(holes{i}, ptsD));
%             D(:, n + cnh(i) + 1 : n + cnh(i+1)) = gather(-cgcoords_derivative_gpu(holes{i}, ptsN));
%             Ds(:, n + cnh(i) + 1 : n + cnh(i+1)) = gather(-cgcoords_derivative_gpu(holes{i}, ptsStatic));
%         end
    else
        C(:, 1:n) = cgcoords(curve, ptsD);
        [~, D(:, 1:n)] = cgcoords(curve, ptsN);
        [~, Ds(:, 1:n)] = cgcoords(curve, ptsStatic);
        for i = 1 : length(holes)
            C(:, n + cnh(i) + 1 : n + cnh(i+1)) = -cgcoords(holes{i}, ptsD);
            [~, D(:, n + cnh(i) + 1 : n + cnh(i+1))] = cgcoords(holes{i}, ptsN);
            D(:, n + cnh(i) + 1 : n + cnh(i+1)) = -D(:, n + cnh(i) + 1 : n + cnh(i+1));
            [~, Ds(:, n + cnh(i) + 1 : n + cnh(i+1))] = cgcoords(holes{i}, ptsStatic);
            Ds(:, n + cnh(i) + 1 : n + cnh(i+1)) = -Ds(:, n + cnh(i) + 1 : n + cnh(i+1));
        end
    end
%     C = gather(cgcoords_gpu(curve, pts));

    p = log(repmat(ptsD, 1, ns) - repmat(sources(:).', length(ptsD), 1)) * Q;
    pN = 1./(repmat(ptsN, 1, ns) - repmat(sources(:).', length(ptsN), 1)) * Q;
    pNs = 1./(repmat(ptsStatic, 1, ns) - repmat(sources(:).', length(ptsStatic), 1)) * Q;
    
    kappa = H * curvature;
    if ~isempty(linesources)
        clsource = line_source(ptsD, linesources(:, 1), linesources(:, 2));
        [~, dlsource] = line_source(ptsN, linesources(:, 1), linesources(:, 2));
        [~, dlsourceS] = line_source(ptsStatic, linesources(:, 1), linesources(:, 2));
    else
        clsource = 0;
        dlsource = 0;
        dlsourceS = 0;
    end

    % Dirrichlet boundary conditions
    bD = -real(p + sum(clsource, 2)) + gamma * kappa;
    % Neumann boundary conditions
    bN = -real((pN + sum(dlsource, 2)) .* nrms);
    % Replace conditions for static verts (to neumann)
    bD(ptsSIndices) = -1*real((pNs + sum(dlsourceS,2)) .* ptsStaticNormals);
    bNs = -1*real((pNs + sum(dlsourceS,2)) .* ptsStaticNormals);

    Dn = bsxfun(@times, D, nrms);
    Dns = bsxfun(@times, Ds, ptsStaticNormals);
    
    A = [real(C), -imag(C(:, 1:end-1));
         real(Dn), -imag(Dn(:, 1:end-1))];
%     A = [A; [real(Dns), -imag(Dns(:, 1:end-1))]];
    A(ptsSIndices, :) = 1*[real(Dns), -imag(Dns(:, 1:end-1))];
    
    b = [bD;bN;];
    
    f = A \ b;

%         f = cgls([real(C), -imag(C(:, 1:end-1))], b, 0, 1e-6, 80);
    f = [f;0];
%     f = complex(f(1:length(curve)), f(length(curve)+1:end));
    f = complex(f(1:end/2), f(end/2+1:end));

%     err = norm(real(C*f)-b);
    f = gather(f);

    % The normals of the curve
    nrmsc = znormals(curve);
    
    
    
    % Calculate the speed...
%     [~, D] = cgsplinecoords(curve, curve - 1e-3 * nrms, 1);
%     D = zeros(n, n + cnh(end));
    vpts = curve - 1e-2*nrmsc;
%     [~, D(:,1:n)] = cgcoords(curve, vpts);
% %     [~, D(:,1:n)] = cgsplinecoords(curve, curve, 3);
%     for i = 1 : length(holes)
%         [~, D(:, n + cnh(i) + 1 : n + cnh(i+1))] = cgcoords(holes{i}, vpts);
% %         [~, D(:, n + cnh(i) + 1 : n + cnh(i+1))] = cgsplinecoords(holes{i}, curve, 3);
%         D(:, n + cnh(i) + 1 : n + cnh(i+1)) = -D(:, n + cnh(i) + 1 : n + cnh(i+1));
%         
%     end
    D = cgcoords_der_mc(curve, holes, vpts);
    
%     D = gather(cgcoords_derivative_gpu(curve, curve - 1e-3*nrmsc));
    if ~isempty(linesources)
        [~, dlines] = line_source(curve, linesources(:, 1), linesources(:, 2));
    else
        dlines = 0;
    end
%     [~, D] = cgsplinecoords(curve, curve, 3);

    if ~isempty(sources)
        dlog = 1./(repmat(curve, 1, ns) - repmat(sources(:).', n, 1)) * Q;
    else
        dlog = 0;
    end

    v = sum(dlines, 2) + ...
        sum(dlog, 2) + ...
            D * f;

    vn = -real(v .* nrmsc);
    
    % Hack for making zero velocity
    ptsinside = logical(zeros(size(vn)));
    for i = 1 : length(holes)
        ptsinside = ptsinside | zinpoly(curve, holes{i});
    end
    vn(ptsinside) = 0;
    
    vt = zeros(size(staticverts));
    for i = 1 : size(staticverts, 1)
        vn(staticverts(i, 1) : staticverts(i, 2)) = 0;
        t1 = curve(staticverts(i, 1)+1) - curve(staticverts(i, 1));
        t1 = t1 ./ abs(t1);
        t2 = curve(staticverts(i, 2)-1) - curve(staticverts(i, 2));
        t2 = t2 ./ abs(t2);
        vt(i, 1) = -real(v(staticverts(i, 1)) .* t1);
        vt(i, 2) = -real(v(staticverts(i, 2)) .* t2);
    end
    
    dfdt = vn .* nrmsc;
    
end

