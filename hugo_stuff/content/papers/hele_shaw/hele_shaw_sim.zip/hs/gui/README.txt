

Creating the setup:
-------------------------------------
New Curve: Create a new initial interface. Click on the left mouse button for adding control points, and on the right mouse button for interpolating them with a spline.

Add Source: Add an injection/suction point. Left mouse button for adding a suction point, right for injection. Press ESCAPE when finished.

Add line source: Left click for adding vertices, Right click to finish.

Add obstacle: Left click for adding control points, right click to finish.


Running the simulation:
--------------------------------------
Simulate: Start/Stop the simulation (left click + drag to move the singularities during the flow)

Reset flow: clear the generated flow and return to the initial interface.

Save simulation: Save the generated flow (as a cell array of curves).

Plot areas: plot the areas of the interior fluid during the flow.


Additional settings:
--------------------------------------
Set -> Number of initial points: Set the number of vertices of the initial curve.

Set -> Gamma: Set the surface tension.

Set -> Draw curve every...: Draw the current interface every X iteratoins.

Set -> Max edge length: The maximum edge length for the curves.

Set -> Delta t: Set the size of the time steps.

Set -> Q change rate: Set the rate of injection/suction (as a function of the time 't').