function varargout = interactive_flow(varargin)
% INTERACTIVE_FLOW MATLAB code for interactive_flow.fig
%      INTERACTIVE_FLOW, by itself, creates a new INTERACTIVE_FLOW or raises the existing
%      singleton*.
%
%      H = INTERACTIVE_FLOW returns the handle to a new INTERACTIVE_FLOW or the handle to
%      the existing singleton*.
%
%      INTERACTIVE_FLOW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in INTERACTIVE_FLOW.M with the given input arguments.
%
%      INTERACTIVE_FLOW('Property','Value',...) creates a new INTERACTIVE_FLOW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before interactive_flow_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to interactive_flow_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help interactive_flow

% Last Modified by GUIDE v2.5 05-Aug-2016 10:41:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
addpath('../utils');
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @interactive_flow_OpeningFcn, ...
                   'gui_OutputFcn',  @interactive_flow_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before interactive_flow is made visible.
function interactive_flow_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to interactive_flow (see VARARGIN)

% Choose default command line output for interactive_flow
handles.output = hObject;

handles.hplot = plot(handles.axes1, 0);
set(handles.hplot, 'xdata', [], 'ydata', []);
hold on
handles.splot = plot(handles.axes1, 0);
set(handles.splot, 'xdata', [], 'ydata', []);

% Default parameters
handles.gamma = 0.001;
handles.draw_interval = 5;
handles.maxedgelength = 0.06;
handles.dtfactor = 0.7;
handles.curves = [];
handles.curves2 = [];
handles.errs = [];
handles.areas = [];
handles.dts = [];
handles.sim_mode = 0;
handles.qrate = 'stypes';
handles.holes = [];
handles.modify_locality = 1;
handles.simdata = [];

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes interactive_flow wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = interactive_flow_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in startflowbutton.
function startflowbutton_Callback(hObject, eventdata, handles)
% hObject    handle to startflowbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes when figure1 is resized.
function figure1_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    axis(handles.axes1, 'equal');


% --- Executes on button press in loadcurvebutton.
function loadcurvebutton_Callback(hObject, eventdata, handles)
% hObject    handle to loadcurvebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    [answer, path] = uigetfile();
    if answer
        ldata = load(strcat(path, '/', answer));
        handles.curve = ldata.curve;
        handles.cs = cscvn([real([handles.curve; handles.curve(1)]).'; ...
                                    imag([handles.curve; handles.curve(1)]).']);
        clear_data(hObject, handles);
        handles.curves = colorcurve(handles.curve, 0);
        guidata(hObject, handles);
%         display_current_curve(handles);
    end

% --- Executes on button press in newcurvebutton.
function newcurvebutton_Callback(hObject, eventdata, handles)
% hObject    handle to newcurvebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    handles = clear_data(hObject, handles);
    
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'off');
    
    set(handles.hplot, 'xdata', [], 'ydata', []);
    set(handles.axes1, 'xlim', [-1 1]);
    set(handles.axes1, 'ylim', [-1 1]);
    set(handles.axes1, 'ButtonDownFcn', @(h, e) add_pt_cb(h, e, handles));
    
    uiwait;
    
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'on');
    % Interpolate the points
    poly = [get(handles.hplot, 'xdata'); get(handles.hplot, 'ydata')];
    if (turning_number(complex(poly(1,:).', poly(2,:).')) > 0)
        poly = fliplr(poly);
    end
    cs = cscvn([poly, poly(:, 1)]);
    % Sample the parametric curve
    [~,t] = fnplt(cs);
    handles.cs = cs;
    handles.psamples = linspace(0, max(t), 101);
    handles.psamples = handles.psamples(1:end-1);
    curve = fnval(cs, handles.psamples);
    handles.curve = complex(curve(1,:), curve(2,:)).';
    
    handles.curves = colorcurve(handles.curve, 0);
    
    set(handles.curves(1), 'ButtonDownFcn', @(h, e) initiate_modify_curve(h, e));
    set(handles.hplot, 'xdata', [], 'ydata', []);
    guidata(hObject, handles);
    
%     display_current_curve(handles);
    delete(findall(handles.figure1, 'type', 'hggroup'));
    

function [] = initiate_modify_curve(h, e)
    handles = guidata(h);
    pos = get(gca, 'CurrentPoint');
    pos = complex(pos(1,1), pos(1,2));
    posx = get(handles.curves(1), 'xdata');
    posy = get(handles.curves(1), 'ydata');
    curve = complex(posx(:, 1), posy(:, 1));
    % Find on which edge the user clicked
    ccurve = curve([2:end 1]);
    edges = curve([2:end 1]) - curve;
    elength = abs(edges);
    edges = edges ./ elength;
    pe = pos - curve;
    dc = conj(pe) .* edges;
    dists = abs(imag(dc));
    outside = real(dc) < 0 | real(dc) > elength;
    dists(outside) = min(abs(pos-curve(outside)), abs(pos-ccurve(outside)));
    [~, i] = min(dists);
    
    locality = str2double(get(handles.edtModifLocality, 'string'));
    
    vstart = mod(i + 1 + locality, length(curve));
    vend = mod(i - locality, length(curve));
    
    if vstart == 0
        vstart = length(curve);
    end
    if vend == 0
        vend = length(curve);
    end
    
    if i + 1 + locality > length(curve) || i - locality < 1
        verts = handles.curve(vstart : vend);
    else
       
        verts = handles.curve([vstart : end, 1 : vend]);
    end
    
    n = length(handles.curve);
    set(handles.figure1, 'WindowButtonMotionFcn', @(h,e) modify_curve(h, e, pos, verts, n));
    set(handles.figure1, 'windowbuttonupfcn', @(h, e) finishedMouseMove(h, e, handles));
    

function modify_curve(h, e, origpos, verts, n)
    handles = guidata(h);
    pos = get(gca, 'CurrentPoint');
    pos = complex(pos(1,1), pos(1,2));
    newcurve = zcscvn([verts; pos]);
    handles.curve = zcsample(newcurve, n);
    handles.curve = sample_spline(handles.curve, n);
    
    zdata = get(handles.curves(1), 'zdata');
    zdata = repmat(zdata(1), length(handles.curve) + 1, 2);
    xdata = repmat(real(handles.curve([1:end 1])), 1, 2);
    ydata = repmat(imag(handles.curve([1:end 1])), 1, 2);
    set(handles.curves(1), 'xdata', xdata, 'ydata', ydata, 'zdata', zdata);
    guidata(h, handles);
    
function [] = mouseMove(h, e, handles)
    pos = get(gca, 'CurrentPoint');
    posx = get(handles.hplot, 'xdata');
    posy = get(handles.hplot, 'ydata');
    if norm([posx(end), posy(end)] - [pos(1,1), pos(1,2)]) > 5e-2
        set(handles.hplot, 'xdata', [posx, pos(1,1)], 'ydata', [posy, pos(1,2)]);
    end
    
    
function [] = stopDraw(h, e, handles)
    set(handles.figure1, 'WindowButtonMotionFcn', []);
    set(handles.figure1, 'windowbuttonupfcn', []);

function [] = add_pt_cb(h, e, handles)
     if e.Button == 1
        pos = get(gca, 'CurrentPoint');
        posx = get(handles.hplot, 'xdata');
        posy = get(handles.hplot, 'ydata');

        set(handles.hplot, 'xdata', [posx, pos(1,1)], 'ydata', [posy, pos(1,2)]);

        pt = impoint(handles.axes1, pos(1, 1:2));
        addNewPositionCallback(pt,@(p) update_pos(p, length(posx) + 1, handles));
        
        set(handles.figure1, 'WindowButtonMotionFcn', @(h,e) mouseMove(h, e, handles));
        set(handles.figure1, 'windowbuttonupfcn', @(h, e) stopDraw(h, e, handles));
        
    else % Right mouse click
        set(handles.axes1, 'ButtonDownFcn', []);
        uiresume;
%         rigpos = get(gca, 'CurrentPoint');
%         set(handles.figure1, 'WindowButtonMotionFcn', @(h,e) move_hole(h, e, origpos, origx, origy, oh));
%         set(handles.figure1, 'windowbuttonupfcn', @(h, e) finishedMouseMove(h, e, handles));
     end
    
function [] = add_pt_src_cb(h, e, handles)
    pos = get(gca, 'CurrentPoint');
    pt = impoint(handles.axes1, pos(1, 1:2));
    
%     addNewPositionCallback(pt,@(p) update_src_pos(p, length(posx) + 1, handles));
     if e.Button == 1
        pt.setColor('r');
    else % Right mouse click
        pt.setColor('b');
    end
    
function [] = update_pos(p, i, handles)
    posx = get(handles.hplot, 'xdata');
    posy = get(handles.hplot, 'ydata');
    posx(i) = p(1);
    posy(i) = p(2);
    set(handles.hplot, 'xdata', posx, 'ydata', posy);
    

% --- Executes on button press in savecurvebutton.
function savecurvebutton_Callback(hObject, eventdata, handles)
% hObject    handle to savecurvebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%     answer = inputdlg('Enter filename:', 'Save curve', 1, {'curve1'});
    [answer, path] = uiputfile({'*.mat'});
    if answer
        curve = handles.curve;
        save(strcat(path, '/', answer), 'curve');
    end

    
function handles = clear_data(hObject, handles, clear_curves, clear_sources)
    global writerObj;
    writerObj = [];
    if nargin < 3
        clear_curves = 1;
    end
    if nargin < 4
        clear_sources = 1;
    end
    if clear_curves
        set(handles.hplot, 'xdata', [], 'ydata', []);
        delete(handles.curves);
        delete(handles.curves2);
        
        
        handles.curves = [];
        handles.curves2 = [];
        handles.simdata = [];
        
        handles.errs = [];
        handles.areas = [];
        handles.dts = [];
    end
    if clear_sources
        delete(findall(handles.figure1, 'type', 'hggroup'));
        delete(findall(handles.figure1, 'tag', 'source_line'));
        delete(handles.holes);
        handles.holes = [];
    end
    guidata(hObject, handles);

% --- Executes on button press in resetflowbutton.
function resetflowbutton_Callback(hObject, eventdata, handles)
% hObject    handle to resetflowbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    clear_data(hObject, handles, 1, 0);
    handles.curves = colorcurve(handles.curve, 0);
    set(handles.curves(1), 'ButtonDownFcn', @(h, e) initiate_modify_curve(h, e));
    guidata(hObject, handles);

% --- Executes on button press in addsourcebutton.
function addsourcebutton_Callback(hObject, eventdata, handles)
% hObject    handle to addsourcebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'off');
    
    set(handles.axes1, 'ButtonDownFcn', @(h, e) add_pt_src_cb(h, e, handles));
    set(handles.figure1, 'KeyPressFcn', @check_key);
    
    uiwait;
    set(handles.axes1, 'ButtonDownFcn', []);
    set(handles.figure1, 'KeyPressFcn', []);
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'on');
    
function check_key(h, e)
    global quitstat;
    if strcmp(e.Key, 'escape')
        quitstat = 0;
        uiresume;
    elseif strcmp(e.Key, 'return')
        quitstat = 1;
        uiresume;
    end
function control_sim_key(h, e, handles)
    if isfield(e, 'Key')
        if strcmp(e.Key, 'escape')
            set(handles.simulatebutton, 'Value', 0);
        end
    end

% --- Executes on button press in saveallbutton.
function saveallbutton_Callback(hObject, eventdata, handles)
% hObject    handle to saveallbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    [answer, path] = uiputfile({'*.mat'});
    if answer
        dt = 0.1;
        maxedgelength = 0.06;
        
        % Find and save all point singularities
        suctions = findall(handles.figure1, 'tag', 'plus', 'color', 'r');
        injections = findall(handles.figure1, 'tag', 'plus', 'color', 'b');
        Q = [3*ones(length(suctions), 1); -3 * ones(length(injections), 1)];
        all = [suctions; injections];
        if length(all) > 1
            sources = complex(cell2mat(get([suctions; injections], 'xdata')), ...
                           cell2mat(get([suctions; injections], 'ydata')));
        else
            sources = complex((get([suctions; injections], 'xdata')), ...
                           (get([suctions; injections], 'ydata')));
        end
        holes = {};
        for i = 1 : length(handles.holes)
            holes{i} = complex(get(handles.holes(i), 'xdata'), get(handles.holes(i), 'ydata'));
            holes{i} = holes{i}(1:end-1);
            holes{i} = holes{i}(:);
        end
        
        % Find and save all lines singularities
        srclines = findall(handles.figure1, 'tag', 'source_line');
        linesxdat = get(srclines, 'xdata');
        linesydat = get(srclines, 'ydata');
        
        curve = handles.curve;
        gamma = handles.gamma;
        
        save(strcat(path, '/', answer), 'curve', 'dt', 'maxedgelength', 'gamma', 'Q', 'sources', 'linesxdat', 'linesydat', 'holes');
        
    end

% --- Executes on button press in loadallbutton.
function loadallbutton_Callback(hObject, eventdata, handles)
% hObject    handle to loadallbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    [answer, path] = uigetfile();
    if answer
        data = load(strcat(path, '/', answer));
        if isempty(data)
            return;
        end
        
        if isfield(data, 'curve')
            clear_data(hObject, handles, 1, get(handles.chkerasesources, 'Value'));
            handles.curve = data.curve;
            handles.curves = colorcurve(handles.curve, 0);
            set(handles.curves(1), 'ButtonDownFcn', @(h, e) initiate_modify_curve(h, e));
        else
            clear_data(hObject, handles, 0, get(handles.chkerasesources, 'Value'));
        end
        handles.cs = cscvn([real([handles.curve; handles.curve(1)]).'; ...
                                    imag([handles.curve; handles.curve(1)]).']);
        if isfield(data, 'gamma')
            handles.gamma = data.gamma;
        end
        if isfield(data, 'Q')
            for i = 1 : length(data.Q)
                pt = impoint(handles.axes1, [real(data.sources(i)), imag(data.sources(i))]);
                if data.Q(i) > 0
                    pt.setColor('r');
                else
                    pt.setColor('b');
                end
            end
        end
        hold on;
        if isfield(data, 'linesxdat') && ~isempty(data.linesxdat)
            if ~iscell(data.linesxdat)
                data.linesxdat = mat2cell(data.linesxdat,size(data.linesxdat, 1));
                data.linesydat = mat2cell(data.linesydat,size(data.linesydat, 1));
            end
            for i = 1 : length(data.linesxdat)
                hl = plot(handles.axes1, data.linesxdat{i}, data.linesydat{i});
                set(hl, 'tag', 'source_line');
                set(hl, 'color', 'r');
                c = uicontextmenu;
                m1 = uimenu(c,'Label','edit','Callback',@editSrcLine, 'UserData', hl);
                m2 = uimenu(c,'Label','delete','Callback',@deleteSrcLine, 'UserData', hl);
                hl.UIContextMenu = c;
                set(hl, 'ButtonDownFcn', @(h, e) initiate_line_move(h, e));
            end
        end
        if isfield(data, 'holes')
            for i = 1 : length(data.holes)
                handles.holes(end+1) = plot(data.holes{i}([1:end 1]));
%                 holes{i} = complex(get(handles.holes(i), 'xdata'), get(handles.holes(i), 'ydata'));
%                 holes{i} = holes{i}(1:end-1);
%                 holes{i} = holes{i}(:);
            end
        end
        
        guidata(hObject, handles);
%         display_current_curve(handles);
    end

% --------------------------------------------------------------------
function mnunumpts_Callback(hObject, eventdata, handles)
% hObject    handle to mnunumpts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    if isfield(handles, 'curve')
        numpts = num2str(length(handles.curve));
    else
        numpts = 100;
    end
    answer = inputdlg('Enter the nubmer of samples in the initial curve:', ...
        'Number of sample points', 1, {numpts});
    if ~isempty(answer)
        num = str2num(answer{1});
        if ~isempty(num)
            handles.curve = sample_spline(handles.curve, num);
            
            guidata(hObject, handles);
            
%             display_current_curve(handles);
        end
    end

% --------------------------------------------------------------------
function mnusetgamma_Callback(hObject, eventdata, handles)
% hObject    handle to mnusetgamma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    answer = inputdlg('Enter a new value for gamma:', ...
        'Gamma', 1, {num2str(handles.gamma)});
    if ~isempty(answer)
        num = str2num(answer{1});
        if ~isempty(num)
            handles.gamma = num;
            guidata(hObject, handles);
        end
    end

% --------------------------------------------------------------------
function mnunew_Callback(hObject, eventdata, handles)
% hObject    handle to mnunew (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function mnusave_Callback(hObject, eventdata, handles)
% hObject    handle to mnusave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function mnuload_Callback(hObject, eventdata, handles)
% hObject    handle to mnuload (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function display_current_curve(handles)
    set(handles.hplot, 'xdata', real([handles.curve; handles.curve(1)]), ...
                       'ydata', imag([handles.curve; handles.curve(1)]));
    


% --------------------------------------------------------------------
function mnudrawinterval_Callback(hObject, eventdata, handles)
% hObject    handle to mnudrawinterval (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    answer = inputdlg('Draw curve every X iterations:', ...
        'Draw curve interval', 1, {num2str(handles.draw_interval)});
    if ~isempty(answer)
        num = str2num(answer{1});
        if ~isempty(num)
            handles.draw_interval = num;
            guidata(hObject, handles);
        end
    end





function lsrc = sget_line_sources(handles)
    srclines = findall(handles.figure1, 'tag', 'source_line');
    if isempty(srclines)
        lsrc = [];
        return;
    end
    xydata = {get(srclines, 'xdata'), get(srclines, 'ydata')};
    if iscell(xydata{1})
        lsrc = [];
        for i = 1 : size(srclines, 1)
            complexdat = complex(xydata{1}{i}, xydata{2}{i});
            lsrc(end + 1: end + length(xydata{1}{i}) - 1, :) = ...
                [complexdat(1:end-1).', complexdat(2:end).'];
        end
    else
        complexdat = complex(xydata{1}, xydata{2});
%         lsrc = [srclines(1:end-1), srclines(2:end)];
        lsrc = [complexdat(1:end-1).', complexdat(2:end).'];
    end
    
function static = find_static_verts(curve, handles)
    obstacles = findall(handles.figure1, 'tag', 'obstacle');
    static = false(size(curve));
    
    for i = 1 : length(obstacles)
        opos = get(obstacles(i), 'Position');
        pt = complex(opos(1) + 0.5*opos(3), opos(2) + 0.5*opos(4));
        if get(obstacles(i), 'Curvature')
            static = static | (abs(curve - pt) <= 0.5*opos(3));
        else
            static = static | (abs(real(curve-pt))<=0.5*opos(3) & abs(imag(curve-pt))<=0.5*opos(4));
        end
        
    end
    
function slow_it_down()
    global slow_down
    slow_down = 1;
    
function unslow_it_down()
    global slow_down
    slow_down = 0;
    
% --- Executes on button press in simulatebutton.
function simulatebutton_Callback(hObject, eventdata, handles)
% hObject    handle to simulatebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global writerObj;
    
    if ~get(handles.simulatebutton, 'Value')
        return;
    end
    
    % Start writing a movie
    if get(handles.recMovieCheck, 'Value') && isempty(writerObj)
        writerObj = VideoWriter('hsmovie.avi');
        writerObj.FrameRate = 30; % or your favorite frame rate
        open(writerObj);
    end
    
    % Draw the first curve if necessary
    if isempty(handles.curves)
        handles.curves = colorcurve(handles.curve, 0);
    end
    % Initialize the second set of curves
    if handles.sim_mode == 3 && isempty(handles.curves2)
        handles.curves2 = handles.curves;
    end

    % Find all singular points
    suctions = findall(handles.figure1, 'tag', 'plus', 'color', 'r');
    injections = findall(handles.figure1, 'tag', 'plus', 'color', 'b');
    Q = [ones(length(suctions), 1); -ones(length(injections), 1)];
    all = [suctions; injections];
    
    % Initialize the strength of the lines singularity
%     QL = ones(size(line_sources, 1), 1);
     
    % Get the last curve
    curve = complex(get(handles.curves(end), 'xdata'), get(handles.curves(end), 'ydata'));
    curve = curve(1:end-1, 1);
    if handles.sim_mode == 3
        curve2 = complex(get(handles.curves2(end), 'xdata'), get(handles.curves2(end), 'ydata'));
        curve2 = curve2(1:end-1, 1);
    end
    if 0
        handles.curves = fill(real(curve), imag(curve), 'r');
    end
    if isempty(handles.simdata)
%         handles.simdata = {curve};
    end
    
    guidata(hObject, handles);
    
    set(handles.figure1, 'KeyPressFcn', @(h, e) control_sim_key(h, e, handles));

    lastcurve = [];
    lastV = [];
    t = sum(handles.dts);
    tmp = load('bluecmap');
    cmap = tmp.cmap;
    
    set(handles.figure1, 'WindowButtonDownFcn',  @(h,e) slow_it_down());
    set(handles.figure1, 'WindowButtonUpFcn', @(h,e) unslow_it_down());
    global slow_down
    
    % Viscosities
    mu1 = str2num(get(handles.editMu1, 'String'));
    mu2 = str2num(get(handles.editMu2, 'String'));

    global staticverts
    if length(handles.dts) < 2
        staticverts = [];
    end
    mc = 0;
    
    holesstat = zeros(size(handles.holes));
    holes = {};
    for i = 1 : length(handles.holes)
        holes{i} = complex(get(handles.holes(i), 'xdata'), get(handles.holes(i), 'ydata'));
        holes{i} = holes{i}(1:end-1);
        holes{i} = holes{i}(:);
        [in, on] = zinpoly(holes{i}, curve);
        if any(~in)
            holesstat(i) = 0;   % Inactive hole
            % TODO: Find static vertices
        else
            holesstat(i) = 1;   % Active hole
        end
    end
    
    while get(handles.simulatebutton, 'Value')
%         set(handles.simulatebutton, 'Value', 0);

        tic
        if length(all) > 1
            sources = complex(cell2mat(get([suctions; injections], 'xdata')), ...
                           cell2mat(get([suctions; injections], 'ydata')));
            stypes = [ones(length(suctions), 1); -ones(length(injections), 1)];
        else
            sources = complex((get([suctions; injections], 'xdata')), ...
                           (get([suctions; injections], 'ydata')));
            stypes = [ones(length(suctions), 1); -ones(length(injections), 1)];
        end
        line_sources = sget_line_sources(handles);
        QL = ones(size(line_sources, 1), 1);
        curve = complex(get(handles.curves(end), 'xdata'), get(handles.curves(end), 'ydata'));
        curve = curve(1:end-1, 1);
        
        err = 0;
        if handles.sim_mode == 0
%             dfdt = hs_ode_fun(curve, sources, Q, handles.gamma, line_sources);
            [dfdt, vt, v] = hs_ode_fun_mc(curve, sources, Q, handles.gamma, line_sources, holes(holesstat~=0), staticverts);
        elseif handles.sim_mode == 1
            [dfdt, err] = hs_ext_ode_fun_v2(curve, sources, Q, handles.gamma, line_sources);
%             [dfdt, vt, v] = hs_ext_odefun_mc(curve, sources, Q, handles.gamma, line_sources, holes, staticverts);
%             dfdt = exterior_hs_ode(0, curve, sources, @(x) Q*2*pi, [], @(x)0, handles.gamma, 4, 1);
        elseif handles.sim_mode == 2
            [dfdt, err] = hs_two_phase_ode_fun_v2(curve, sources, Q, handles.gamma, line_sources, mu1, mu2);
        elseif handles.sim_mode == 3
            dfdt = hs_ode_fun(curve, sources, Q, handles.gamma, line_sources);
            [dfdt2, err] = hs_ext_ode_fun_v2(curve2, sources, -Q, handles.gamma, line_sources);
        end
%         static = find_static_verts(curve, handles);

        handles.errs(end + 1) = err;
        
        dt = min(abs(curve-circshift(curve,1,1))./(abs(dfdt)))*handles.dtfactor;
%         dt = 0.5e-2;

        if slow_down
%             dt = dt * 0.3;
        end

        handles.dts(end + 1) = dt;
        t = t + dt;
        % Update Q
%         Q = Q + handles.qrate * dt;
        Q = eval(handles.qrate);

        % Advance the curve
%         curve = curve - dt * conj(v);

        % Cheat 1 - avoid wrong velocities
        if handles.sim_mode == 0
            bad = Q * real(conj(dfdt) .* znormals(curve)) > 0;
            dfdt(bad) = 0;
        elseif handles.sim_mode == 1
            bad = Q * real(conj(dfdt) .* znormals(curve)) > 0;
            dfdt(bad) = 0;
        end
        
        
        % Cheat 2 - avoid intersections
%         tmpcurve = curve + dt * dfdt;
%         [selfintersect, i1, i2] = zintersect(tmpcurve);
%         for i = 1:2:length(i2)
%             dfdt(i2(i):i2(i+1)+1) = 0;
% %             curve(i2(i):i2(i+1)+1) = curve(i2(i):i2(i+1)+1) - dt * dfdt(i2(i):i2(i+1)+1);
%         end
%         
%         % Recalculate dt
%         dt = min(abs(curve-circshift(curve,1,1))./(abs(dfdt)))*handles.dtfactor;
        curve = curve + dt * dfdt;
        
       
        
        if handles.sim_mode == 3
            dt = min(abs(curve2-circshift(curve2,1,1))./(abs(dfdt2)))*handles.dtfactor;
            curve2 = curve2 + dt * dfdt2;
        end
%         curve = 0.5*(curve + circshift(curve, 1)) + dt * dfdt;

        % Store the area of the curve
        handles.areas(end + 1) = polyarea(real(curve), imag(curve));

%         [curve, cs, psamples] = resample_curve(curve, handles.maxedgelength);
%         curve = resample_cb(curve, pi/6);
%         curve = sample_spline(curve, 600, 2e-2, 1.5, staticverts);

        % Calculate the minimm edge according to the curve scale
%         minedge = 0.8e-2*abs(complex(max(real(curve)), max(imag(curve))) - ...
%             complex(min(real(curve)), min(imag(curve)))      );
        minedge = 1e-2;

        % Resample the curve
        [curve, staticverts] = sample_spline(curve, 2000, minedge, 1.5, staticverts);
        if handles.sim_mode == 3
            curve2 = sample_spline(curve2, 1000, 2e-2);
        end

        if get(handles.recMovieCheck, 'Value')
            simdata.curve = curve;
            simdata.sources = sources;
            simdata.Q = Q;
            simdata.gamma = handles.gamma;
            simdata.linesources = line_sources;
            handles.simdata{end + 1} = simdata;
        end
        
        if 0
            set(handles.curves(end), 'xdata', real(curve), 'ydata', imag(curve));
        else
            if mod(length(handles.errs), handles.draw_interval) == 0
                
                handles.curves(end + 1) = colorcurve(curve, length(handles.curves) + 1);
                if handles.sim_mode == 3
                    handles.curves2(end + 1) = colorcurve(curve2, length(handles.curves2) + 1);
                end
                colormap(cmap)
            else
                %             set(handles.curves(end), 'xdata', repmat(real([curve; curve(1)]), 1, 2), ...
                %                                      'ydata',repmat(imag([curve; curve(1)]), 1, 2), ...
                %                                      'zdata',repmat(length(handles.curves), 1+length(curve), 2), ...
                %                                      'cdata',repmat(length(handles.curves), 1+length(curve), 2));
                delete(handles.curves(end));
                handles.curves(end) = colorcurve(curve, length(handles.curves));
                if handles.sim_mode == 3
                    delete(handles.curves2(end));
                    handles.curves2(end) = colorcurve(curve2, length(handles.curves2));
                end
                colormap(cmap)
            end
        end

        guidata(hObject, handles);
%         drawnow;
%         pause(0.01);
%         xlim([-10, 2.5]);
%         ylim([-1.2, 8]);
        pause(0.000001);
        if get(handles.recMovieCheck, 'Value') && ...
                floor(t ./ handles.dts(1)) > floor((t - dt) ./ handles.dts(1))
            frame = getframe;
            writeVideo(writerObj, frame);
        end
        elapsed = toc;
%         pause(max(0.01 - elapsed, 0));
        
    end
    set(handles.figure1, 'KeyPressFcn', []);
    set(handles.figure1, 'WindowButtonDownFcn',  []);
    set(handles.figure1, 'WindowButtonUpFcn', []);
    slow_down = 0;
    
    guidata(hObject, handles);
    


% --- Executes on button press in deformbutton.
function deformbutton_Callback(hObject, eventdata, handles)
% hObject    handle to deformbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'off');
    
    global src_pos;
    global dst_pos;
    src_pos = [];
    dst_pos = [];
    
    % Get the current curve
    curve = complex(get(handles.curves(end), 'xdata'), get(handles.curves(end), 'ydata'));
    curve = curve(:, 1);
    
    % Calculate the cage
    global cage;
    cage = get_cage(curve);
    cage = cage(1:end-1);
    
    % Calculate the inverse of the coords matrix
    global dd;
    nrms = -1i*(cage - circshift(cage, 1));
    nrms = nrms ./ abs(nrms);
%     [~, ~, dd] = cgcoords(cage, (cage + circshift(cage, 1)) * 0.5 - 1e-3 * nrms);
    [~, ~, dd] = cgcoords(cage, (curve + circshift(curve, 1)) * 0.5);
    
    global curve_coords;
    curve_coords = cgcoords(cage, curve);
    hold on;
    handles.hdeform = plot(handles.axes1, 0);
    guidata(hObject, handles);
    
    set(handles.axes1, 'ButtonDownFcn', @(h, e) add_deform_point(h, e, hObject, handles));
    set(handles.figure1, 'KeyPressFcn', @check_key);
    global quitstat
    quitstat = 0;
    
    uiwait;
    if quitstat
        handles.curve = complex(get(handles.hdeform, 'xdata'), ...
                                get(handles.hdeform, 'ydata'));
        handles.curve = reshape(handles.curve(1:end-1), length(handles.curve) - 1, 1);
        clear_data(hObject, handles, 1, 0);
        handles.curves = colorcurve(handles.curve, 0);
        guidata(hObject, handles);
    end
    tmp = findall(handles.figure1, 'tag', 'plus', 'color', [0, 0, 0]);
    for i = 1 : length(tmp)
        delete(tmp(i).Parent);
    end
    delete(handles.hdeform);
    
    set(handles.axes1, 'ButtonDownFcn', []);
    set(handles.figure1, 'KeyPressFcn', []);
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'on');

function [] = add_deform_point(h, e, hObject, handles)
    
    pos = get(gca, 'CurrentPoint');

    pt = impoint(handles.axes1, pos(1, 1:2));
    pt.setColor([0, 0, 0]);
    % Add the point to the list
    global src_pos;
    global dst_pos;
    src_pos(end + 1) = complex(pos(1,1), pos(1,2));
    dst_pos(end + 1) = complex(pos(1,1), pos(1,2));
    
    global cage;
    global dd;
    
    c = cgcoords(cage, src_pos);
    
    global cinv;
    cinv = pinv([c; 0.1 * dd]);
    cinv = cinv(:, 1:length(cage));
    
    % Add callback when the point is dragged
    addNewPositionCallback(pt,@(p) deform(p, length(src_pos), handles));


function cage = get_cage(curve)
    normals = 1i .* (circshift(curve, 1) - circshift(curve, -1));
    normals = normals ./ abs(normals);
    
%     e = convhull(real(curve), imag(curve));
    cage = curve + 1e-3 * normals;
    
function deform(p, i, handles)
    global dst_pos;
    dst_pos(i) = complex(p(1), p(2));
    global cinv;
    u = cinv * [dst_pos(:); zeros(size(cinv, 1) - length(dst_pos), 1)];
    global curve_coords;
    deformed_curve = curve_coords * u;
    set(handles.hdeform, 'xdata', real(deformed_curve), 'ydata', imag(deformed_curve));


% --------------------------------------------------------------------
function mnumaxedgelength_Callback(hObject, eventdata, handles)
% hObject    handle to mnumaxedgelength (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    answer = inputdlg('Enter the maximum allowed edge length:', ...
        'Max edge length', 1, {num2str(handles.maxedgelength)});
    if ~isempty(answer)
        num = str2num(answer{1});
        if ~isempty(num)
            handles.maxedgelength = num;
            guidata(hObject, handles);
        end
    end


% --------------------------------------------------------------------
function mnudeltat_Callback(hObject, eventdata, handles)
% hObject    handle to mnudeltat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    answer = inputdlg('Enter the delta t:', ...
        'Delta t', 1, {num2str(handles.dtfactor)});
    if ~isempty(answer)
        num = str2num(answer{1});
        if ~isempty(num)
            handles.dtfactor = num;
            guidata(hObject, handles);
        end
    end


% --- Executes on button press in addlinesrcbutton.
function addlinesrcbutton_Callback(hObject, eventdata, handles)
% hObject    handle to addlinesrcbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'off');
    
    hold on
    handles.hsrcline = plot(handles.axes1, 0);
    set(handles.hsrcline, 'xdata', [], 'ydata', []);
    set(handles.hsrcline, 'color', 'r');
    guidata(hObject, handles);
    
    set(handles.axes1, 'ButtonDownFcn', @(h, e) add_line_src(h, e, handles, handles.hsrcline));
    set(handles.figure1, 'KeyPressFcn', @check_key);
    
    
    uiwait;
    global quitstat
    if quitstat == 0
        delete(handles.hsrcline);
    else
        set(handles.hsrcline, 'tag', 'source_line');
        c = uicontextmenu;
        m1 = uimenu(c,'Label','edit','Callback',@editSrcLine, 'UserData', handles.hsrcline);
        m2 = uimenu(c,'Label','delete','Callback',@deleteSrcLine, 'UserData', handles.hsrcline);
        handles.hsrcline.UIContextMenu = c;
        
        set(handles.hsrcline, 'ButtonDownFcn', @(h, e) initiate_line_move(h, e));
    end
    
    % Delete the points
    
%     h1 = findall(handles.figure1, 'tag', 'plus', 'color', [0, 0, 0.99]);
%     for i = 1 : length(h1)
%         delete(h1(i).Parent);
%     end
    
    handles.hsrcline = [];
    guidata(hObject, handles);
    
    set(handles.axes1, 'ButtonDownFcn', []);
    set(handles.figure1, 'KeyPressFcn', []);
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'on');

function deleteSrcLine(h, ~)
    delete(get(h, 'userdata'));
    delete(h.Parent);

function initiate_line_move(h, ~)
    handles = guidata(h);
    pos = get(gca, 'CurrentPoint');
    pos = complex(pos(1,1), pos(1,2));
    xdata = get(h, 'xdata');
    ydata =  get(h, 'ydata');
    set(handles.figure1, 'WindowButtonMotionFcn', @(hndl,e) move_line(hndl, h, pos, xdata, ydata));
    set(handles.figure1, 'windowbuttonupfcn', @(h, e) finishedMouseMove(h, e, handles));
    
    
    
function move_line(h, hndl, origpos, linex, liney)
    pos = get(gca, 'CurrentPoint');
    pos = complex(pos(1,1), pos(1,2));
    shift = pos - origpos;
    set(hndl, 'xdata', linex + real(shift), 'ydata', liney + imag(shift));
    
    
function editSrcLine(h, ~)
    handles = guidata(h);
    xdata = get(h.UserData, 'xdata');
    ydata = get(h.UserData, 'ydata');
    set(handles.axes1, 'ButtonDownFcn', @(h, e) add_line_src(h, e, handles, h.UserData));
    for i = 1 : length(xdata)
        pt = impoint(handles.axes1, [xdata(i), ydata(i)]);
        pt.setColor([0.99, 0, 0]);
        addNewPositionCallback(pt,@(p) update_line_src_pos(p, i, h.UserData));
    end
    guidata(h);
    
function add_line_src(h, e, handles, hsrcline)
    if e.Button == 1
        
        pos = get(gca, 'CurrentPoint');
        pt = impoint(handles.axes1, pos(1, 1:2));
        pt.setColor([0.99, 0, 0]);
        
        xdat = get(hsrcline, 'xdata');
        ydat = get(hsrcline, 'ydata');
        set(hsrcline, 'xdata', [xdat, pos(1,1)], 'ydata', [ydat, pos(1,2)]);
        addNewPositionCallback(pt,@(p) update_line_src_pos(p, length(xdat) + 1, hsrcline));
     
    else % Right mouse click
%         pt.setColor([0, 0, 0.99]);
        global quitstat
        quitstat = 1;
        h1 = findall(handles.figure1, 'tag', 'plus', 'color', [0.99, 0, 0]);
        for i = 1 : length(h1)
            delete(h1(i).Parent);
        end
        set(handles.axes1, 'ButtonDownFcn', []);
        uiresume;
     end
    
function update_line_src_pos(p, i, hsrcline)
    xdat = get(hsrcline, 'xdata');
    ydat = get(hsrcline, 'ydata');
    xdat(i) = p(1);
    ydat(i) = p(2);
    set(hsrcline, 'xdata', xdat, 'ydata', ydat);


% --- Executes on button press in plotareasbutton.
function plotareasbutton_Callback(hObject, eventdata, handles)
% hObject    handle to plotareasbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    if ~isempty(handles.areas)
        figure;
        plot(cumsum(handles.dts), handles.areas);
    end


% --- Executes on button press in addobstaclebutton.
function addobstaclebutton_Callback(hObject, eventdata, handles)
% hObject    handle to addobstaclebutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%     if get(handles.addobstaclebutton, 'Value')
%         set(handles.axes1, 'ButtonDownFcn', @(h, e) add_obstacle(h, e, handles));
%     else
%         set(handles.axes1, 'ButtonDownFcn', []);
%     end
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'off');
    set(handles.hplot, 'xdata', [], 'ydata', []);
    set(handles.axes1, 'ButtonDownFcn', @(h, e) add_hole(h, e, handles));
    uiwait
    poly = [get(handles.hplot, 'xdata'); get(handles.hplot, 'ydata')];
    if (turning_number(complex(poly(1,:).', poly(2,:).')) > 0)
        poly = fliplr(poly);
    end
    cs = cscvn([poly, poly(:, 1)]);

    handles.holes(end + 1) = plot(handles.axes1, zcsample(cs, linspace(0, 1, 30)));

    % Context menu for the new added hole
    c = uicontextmenu;
    m1 = uimenu(c,'Label','delete','Callback',@(h,e) delete_hole(h, e), 'UserData', handles.holes(end));
    set(handles.holes(end), 'UIContextMenu', c);
    
    set(handles.holes(end), 'ButtonDownFcn', @(h, e) initiate_move_hole(h, e));
    
    guidata(hObject, handles);
    delete(findall(handles.figure1, 'type', 'hggroup'));
    set(handles.hplot, 'xdata', [], 'ydata', []);
    set(findall(handles.figure1, 'style', 'pushbutton'), 'enable', 'on');
    
    
function add_hole(h, e, handles)
    if e.Button == 1
        pos = get(gca, 'CurrentPoint');
        posx = get(handles.hplot, 'xdata');
        posy = get(handles.hplot, 'ydata');

        set(handles.hplot, 'xdata', [posx, pos(1,1)], 'ydata', [posy, pos(1,2)]);

        pt = impoint(handles.axes1, pos(1, 1:2));
        addNewPositionCallback(pt,@(p) update_pos(p, length(posx) + 1, handles));
        
        set(handles.figure1, 'WindowButtonMotionFcn', @(h,e) mouseMove(h, e, handles));
        set(handles.figure1, 'windowbuttonupfcn', @(h, e) stopDraw(h, e, handles));

    else % Right mouse click
        set(handles.axes1, 'ButtonDownFcn', []);
        uiresume;
    end

function delete_hole(h, e)
    hl = get(h, 'userdata');
    handles = guidata(h);
    handles.holes(handles.holes == hl) = [];
    delete(hl);
    guidata(h, handles);
    
function initiate_move_hole(oh, e)
    origpos = get(gca, 'CurrentPoint');
    origx = get(oh, 'xdata');
    origy = get(oh, 'ydata');
    handles = guidata(oh);
    set(handles.figure1, 'WindowButtonMotionFcn', @(h,e) move_hole(h, e, origpos, origx, origy, oh));
    set(handles.figure1, 'windowbuttonupfcn', @(h, e) finishedMouseMove(h, e, handles));
    
function move_hole(h, e, origpos, origx, origy, oh)
    pos = get(gca, 'CurrentPoint');
    offset = pos - origpos;
    
    set(oh, 'xdata', origx + offset(1,1), 'ydata', origy + offset(1,2));
    
% function add_obstacle(h, e, handles)
%     pos = get(gca, 'CurrentPoint');
% %     oh = plot(handles.axes1, pos(1,1), pos(1,2), 'marker', 'o', ...
% %         'markersize', 10, 'markerfacecolor', [0, 0, 0], 'tag', 'obstacle');
%     oh = rectangle('Position', [pos(1,1), pos(1,2), 0, 0], 'Curvature', [1,1], 'tag', 'obstacle', 'facecolor', [0, 0, 0]);
%     
%     set(handles.figure1, 'WindowButtonMotionFcn', @(h,e) changeObstacleSize(h, e, oh));
%     set(handles.figure1, 'windowbuttonupfcn', @(h, e) finishedMouseMove(h, e, handles));
%     set(oh, 'ButtonDownFcn', @(h, e) obstacleClick(h, e, oh, handles));
%     c = uicontextmenu;
%     m1 = uimenu(c,'Label','change type','Callback',@changeObstacleType, 'UserData', oh);
%     m2 = uimenu(c,'Label','delete','Callback',@deleteObstacle, 'UserData', oh);
%     oh.UIContextMenu = c;
    
% function obstacleClick(h, e, oh, handles)
%     pos = get(gca, 'CurrentPoint');
%     opos = get(oh, 'Position');
%     if e.Button == 1
%         set(handles.figure1, 'WindowButtonMotionFcn', ...
%             @(h,e) moveObstacle(h, e, oh, [pos(1,1) - opos(1), pos(1,2) - opos(2)]));
%     else
%         set(handles.figure1, 'WindowButtonMotionFcn', @(h,e) changeObstacleSize(h, e, oh));
%     end
%     set(handles.figure1, 'windowbuttonupfcn', @(h, e) finishedMouseMove(h, e, handles));
    
% function moveObstacle(h, e, oh, offset)
%     pos = get(gca, 'CurrentPoint');
%     opos = get(oh, 'Position');
%     
%     opos(1) = pos(1,1) - offset(1);
%     opos(2) = pos(1,2) - offset(2);
%     set(oh, 'Position', opos);
%     
% function changeObstacleSize(h, e, oh)
%     pos = get(gca, 'CurrentPoint');
%     ohpos = get(oh, 'Position');
%     ohcenter = complex(ohpos(1)+0.5*ohpos(3), ohpos(2)+0.5*ohpos(4));
%     if get(oh, 'Curvature')
%         newr = abs(complex(pos(1,1), pos(1,2)) - ohcenter);
%         set(oh, 'Position', [real(ohcenter)-newr, imag(ohcenter)-newr, 2*newr, 2*newr]);
%     else
%         newr = abs([pos(1,1) - real(ohcenter), pos(1,2) - imag(ohcenter)]);
%         set(oh, 'Position', [real(ohcenter)-newr(1), ...
%             imag(ohcenter)-newr(2), 2*newr]);
%     end
    
function finishedMouseMove(h, e, handles)
    set(handles.figure1, 'WindowButtonMotionFcn', []);
    set(handles.figure1, 'windowbuttonupfcn', []);

% function changeObstacleType(h, ~)
%     oh = get(h, 'Userdata');
%     set(oh, 'Curvature', 1 - get(oh, 'Curvature'));
%     
%     
% function deleteObstacle(h, ~)
%     delete(get(h, 'userdata'));
%     delete(h.Parent);
    
function curve = getLastCurve(handles)
    curve = complex(get(handles.curves(end), 'xdata'), get(handles.curves(end), 'ydata'));
    if size(curve, 2) == 2
        curve = curve(:, 1);
    else
        curve = curve(:);
    end
    curve = curve(1:end-1);


    
    
function add_bump(h, e, handles)
    
    pos = get(gca, 'CurrentPoint');
    pos = complex(pos(1,1), pos(1,2));
    curve = getLastCurve(handles);
    [~, i] = min(abs(curve - pos));
    
    set(handles.figure1, 'WindowButtonMotionFcn', @(h,e) adjustBump(h, e, pos, i, curve, handles));
    set(handles.figure1, 'windowbuttonupfcn', @(h, e) finishedMouseMove(h, e, handles));
    
function adjustBump(h, e, origpos, indx, curve, handles)
    pos = get(gca, 'CurrentPoint');
    pos = complex(pos(1, 1), pos(1, 2));
    new_curve = curve;
    new_curve(indx) = pos;
    cs = cscvn([real([new_curve;new_curve(1)]), imag([new_curve;new_curve(1)])].');
    
    [~,t] = fnplt(cs);
    pcurve = fnval(cs, linspace(0, max(t), length(curve) + 1));
%     pcurve = pcurve(1:end-1).';
    set(handles.curves(end), 'xdata', [pcurve(1,:);pcurve(1,:)].', ...
                             'ydata', [pcurve(2,:);pcurve(2,:)].');
    


% --- Executes on button press in saveMovieButton.
function saveMovieButton_Callback(hObject, eventdata, handles)
% hObject    handle to saveMovieButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    % For saving a movie
%     global writerObj;
%     close(writerObj);
%     writerObj = [];
    % For saving the simulation
    [answer, path] = uiputfile({'*.mat'});
    if answer
        data = handles.simdata;
        holes = {};
        for i = 1 : length(handles.holes)
            holes{i} = complex(get(handles.holes(i), 'xdata'), get(handles.holes(i), 'ydata'));
            holes{i} = holes{i}(1:end-1);
            holes{i} = holes{i}(:);
        end
        save(strcat(path, '/', answer), 'data', 'holes');
    end
    

% --- Executes on button press in recMovieCheck.
function recMovieCheck_Callback(hObject, eventdata, handles)
% hObject    handle to recMovieCheck (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of recMovieCheck


% --- Executes on button press in rbInterior.
function rbInterior_Callback(hObject, eventdata, handles)
% hObject    handle to rbInterior (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(handles.rbExterior, 'Value', 0);
    set(handles.rbTwoPhase, 'Value', 0);
    set(handles.rbIntExt, 'Value', 0);
    handles.sim_mode = 0;
    
    guidata(hObject, handles);


% --- Executes on button press in rbExterior.
function rbExterior_Callback(hObject, eventdata, handles)
% hObject    handle to rbExterior (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(handles.rbInterior, 'Value', 0);
    set(handles.rbTwoPhase, 'Value', 0);
    set(handles.rbIntExt, 'Value', 0);
    handles.sim_mode = 1;
    guidata(hObject, handles);


% --- Executes on button press in rbTwoPhase.
function rbTwoPhase_Callback(hObject, eventdata, handles)
% hObject    handle to rbTwoPhase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(handles.rbExterior, 'Value', 0);
    set(handles.rbInterior, 'Value', 0);
    set(handles.rbIntExt, 'Value', 0);
    handles.sim_mode = 2;
    guidata(hObject, handles);


% --- Executes on button press in rbIntExt.
function rbIntExt_Callback(hObject, eventdata, handles)
% hObject    handle to rbIntExt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(handles.rbExterior, 'Value', 0);
    set(handles.rbTwoPhase, 'Value', 0);
    set(handles.rbInterior, 'Value', 0);
    handles.sim_mode = 3;
    guidata(hObject, handles);


% --------------------------------------------------------------------
function mnuqrate_Callback(hObject, eventdata, handles)
% hObject    handle to mnuqrate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    answer = inputdlg(sprintf('Enter Q as a function of t:\n\nYou can use:\nQ - current rate\ndt - current time step\nstypes - vector of 1 for suction, -1 for injection\n\n'), ...
        'Suction rate', 1, {num2str(handles.qrate)});
    if ~isempty(answer)
        t = 0;
        try
%             a = eval(answer{1});
            handles.qrate = answer{1};
            guidata(hObject, handles);
            
        catch exception
            errordlg('Invalid expression.');
        end
    end



function editMu1_Callback(hObject, eventdata, handles)
% hObject    handle to editMu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editMu1 as text
%        str2double(get(hObject,'String')) returns contents of editMu1 as a double


% --- Executes during object creation, after setting all properties.
function editMu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editMu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editMu2_Callback(hObject, eventdata, handles)
% hObject    handle to editMu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editMu2 as text
%        str2double(get(hObject,'String')) returns contents of editMu2 as a double


% --- Executes during object creation, after setting all properties.
function editMu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editMu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end



function edtModifLocality_Callback(hObject, eventdata, handles)
% hObject    handle to edtModifLocality (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtModifLocality as text
%        str2double(get(hObject,'String')) returns contents of edtModifLocality as a double


% --- Executes during object creation, after setting all properties.
function edtModifLocality_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtModifLocality (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in chkerasesources.
function chkerasesources_Callback(hObject, eventdata, handles)
% hObject    handle to chkerasesources (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkerasesources


% --------------------------------------------------------------------
function mnuHelp_Callback(hObject, eventdata, handles)
% hObject    handle to mnuHelp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    helpdlg({'Creating the setup:', '-------------------------------------', 'New Curve: Create a new initial interface. Click on the left mouse button for adding control points, and on the right mouse button for interpolating them with a spline.', '', 'Add Source: Add an injection/suction point. Left mouse button for adding a suction point, right for injection. Press ESCAPE when finished.', '', 'Add line source: Left click for adding vertices, Right click to finish.', '', 'Add obstacle: Left click for adding control points, right click to finish.', '', '', 'Running the simulation:', '--------------------------------------', 'Simulate: Start/Stop the simulation.', '', 'Reset flow: clear the generated flow and return to the initial interface.', '', 'Save simulation: Save the generated flow (as a cell array of curves).', '', 'Plot areas: plot the areas of the interior fluid during the flow.', '', '', 'Additional settings:', '--------------------------------------', 'Set -> Number of initial points: Set the number of vertices of the initial curve.', '', 'Set -> Gamma: Set the surface tension.', '', 'Set -> Draw curve every...: Draw the current interface every X iteratoins.', '', 'Set -> Max edge length: The maximum edge length for the curves.', '', 'Set -> Delta t: Set the size of the time steps.', '', 'Set -> Q change rate: Set the rate of injection/suction (as a function of the time t).'});
    
