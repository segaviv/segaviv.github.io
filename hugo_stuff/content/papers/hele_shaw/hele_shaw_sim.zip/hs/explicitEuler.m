function [ curves, ts, areas, fs ] = explicitEuler( initialcurve, odefunc, dtfunc, maxt, maxiter, minedge, maxpts, show)

    curve = initialcurve;
    t = 0;
    curves = {curve};
    fs = {};
    ts = 0;
    areas = polyarea(real(curve), imag(curve));
    
    if show > 0
        cm = load('bluecmap');
        
        figure;
        colorcurve(curve, 0);
        colormap(cm.cmap);
        hold on
        axis equal
        title('Press any key to start the simulation');
        
        waitforbuttonpress;
        
    end
    
    for i = 1 : maxiter
        fprintf('Curiter: %d\n', i);

        [dfdt, f] = odefunc( t, curve );
        fs{end + 1} = f;
        
        dt = dtfunc(curve, dfdt, t);
        
       
        curve = curve + dt * dfdt;
                  
        curve = sample_spline(curve, maxpts, minedge, 2);
        
        if mod(i, show) == 0
            colorcurve(curve, i);
            colormap(cm.cmap);
            drawnow
        end
        
        curves{end+1} = curve;
        t = t + dt;
        
        ts(end+1) = t;
        areas(end+1) = polyarea(real(curve), imag(curve));
        
        if t >= maxt
            break;
        end
    end


end

