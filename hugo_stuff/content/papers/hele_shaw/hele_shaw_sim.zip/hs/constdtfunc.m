function [ func ] = constdtfunc( dt )

    func = @(c, v, t) dt;

end

